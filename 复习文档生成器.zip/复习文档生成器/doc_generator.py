# -*- coding: utf-8 -*-
"""
复习文档生成器 — DeepSeek API 文档生成引擎
功能：把提示词发给 DeepSeek → 收到 Markdown → 转成 .docx
     支持流式输出（进度展示）+ 重试机制 + 断点续传
创建日期：2026-06-27
"""

import os
import json
import time

# ============================================================
# 依赖检查（优雅降级）
# ============================================================
try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

try:
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False

from config import (
    DEEPSEEK_BASE_URL, DEEPSEEK_MODEL, API_CONFIG,
    OUTPUT_DIR
)


# ============================================================
# API Key 管理
# ============================================================

SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings.json')


def load_api_key():
    """从 settings.json 读取 DeepSeek API Key"""
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data.get('deepseek_api_key', '')
        except (json.JSONDecodeError, IOError):
            return ''
    return ''


def save_api_key(api_key):
    """保存 DeepSeek API Key 到 settings.json"""
    data = {}
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    data['deepseek_api_key'] = api_key
    # 也检查环境变量
    data['_note'] = '这是DeepSeek API Key，仅存储在本机，不会上传。'
    with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ============================================================
# DeepSeek 调用
# ============================================================

class DocGenerator:
    """
    文档生成器核心类
    用法：
        gen = DocGenerator(api_key='sk-xxx')
        gen.set_callback(on_progress)   # 可选——进度回调
        result = gen.generate(prompt)   # 返回 Markdown 文本
    """

    def __init__(self, api_key):
        if not HAS_OPENAI:
            raise ImportError(
                '缺少 openai 库。请运行：\n'
                'pip install openai'
            )
        if not api_key or not api_key.startswith('sk-'):
            raise ValueError(
                'API Key 格式不正确。DeepSeek Key 以 sk- 开头。\n'
                '请去 https://platform.deepseek.com/api_keys 获取。'
            )

        self.api_key = api_key
        self.client = OpenAI(
            api_key=api_key,
            base_url=DEEPSEEK_BASE_URL,
        )
        self.on_progress = None  # callback(text_chunk: str)
        self.on_status = None    # callback(status: str)
        self.full_text = ''
        self.is_cancelled = False
        self.raw_markdown_path = None  # 保存的原始 Markdown 路径

    def set_callback(self, on_progress=None, on_status=None):
        """设置进度和状态回调函数"""
        self.on_progress = on_progress
        self.on_status = on_status

    def cancel(self):
        """取消当前生成"""
        self.is_cancelled = True

    def _status(self, msg):
        if self.on_status:
            self.on_status(msg)

    def _progress(self, chunk):
        self.full_text += chunk
        if self.on_progress:
            self.on_progress(chunk)

    def generate(self, prompt, stream=True):
        """
        调用 DeepSeek API 生成文档。
        参数：
            prompt: 完整提示词字符串
            stream: True=流式输出（推荐，能看到生成过程）
        返回：
            dict {
                'success': True/False,
                'text': 'Markdown全文',
                'tokens_used': 1234,
                'error': '错误信息（仅失败时）'
            }
        """
        self.full_text = ''
        self.is_cancelled = False

        if not prompt or len(prompt) < 50:
            return {'success': False, 'error': '提示词太短（<50字符），请检查表单输入。', 'text': ''}

        self._status('正在连接 DeepSeek...')
        last_error = None

        for attempt in range(API_CONFIG['max_retries']):
            if self.is_cancelled:
                return {'success': False, 'error': '用户取消', 'text': self.full_text}

            try:
                self._status(f'正在生成文档... (第{attempt+1}次尝试)')

                response = self.client.chat.completions.create(
                    model=DEEPSEEK_MODEL,
                    messages=[
                        {
                            'role': 'system',
                            'content': (
                                '你是一位专业的教师，正在为学生生成一份期末复习完全指南。'
                                '请严格按提示词要求输出完整的复习文档。'
                                '直接输出文档正文（Markdown格式），不要输出前言、后语、'
                                '或"这是您要的文档"之类的客套话。'
                            )
                        },
                        {'role': 'user', 'content': prompt},
                    ],
                    temperature=API_CONFIG['temperature'],
                    max_tokens=API_CONFIG['max_tokens'],
                    stream=stream,
                    timeout=API_CONFIG['timeout'],
                )

                if stream:
                    # 流式接收
                    for chunk in response:
                        if self.is_cancelled:
                            # 尝试关闭连接
                            try:
                                response.close()
                            except Exception:
                                pass
                            return {'success': False, 'error': '用户取消', 'text': self.full_text}

                        delta = chunk.choices[0].delta
                        if delta and delta.content:
                            self._progress(delta.content)

                    # 流式模式下 token 统计不精确，给个估算
                    tokens_used = len(self.full_text) // 2  # 中文 ≈ 1 char per token
                else:
                    # 非流式
                    content = response.choices[0].message.content
                    self._progress(content)
                    tokens_used = response.usage.total_tokens if response.usage else 0

                self._status('文档生成完成！')
                return {
                    'success': True,
                    'text': self.full_text,
                    'tokens_used': tokens_used,
                }

            except Exception as e:
                last_error = str(e)
                # 分类错误
                if '401' in last_error or 'Unauthorized' in last_error:
                    return {
                        'success': False,
                        'error': 'API Key 无效。请检查 DeepSeek Key 是否正确。',
                        'text': '',
                    }
                elif '402' in last_error or 'Insufficient' in last_error:
                    return {
                        'success': False,
                        'error': 'DeepSeek 账户余额不足，请充值。',
                        'text': '',
                    }
                elif '429' in last_error or 'Rate' in last_error:
                    wait = (attempt + 1) * 5
                    self._status(f'请求太频繁，{wait}秒后重试...')
                    time.sleep(wait)
                elif 'timeout' in last_error.lower():
                    self._status(f'超时，正在重试...（{attempt+1}/{API_CONFIG["max_retries"]}）')
                    time.sleep(2)
                else:
                    self._status(f'网络错误，{2}秒后重试...（{attempt+1}/{API_CONFIG["max_retries"]}）')
                    time.sleep(2)

        return {
            'success': False,
            'error': f'生成失败（重试{API_CONFIG["max_retries"]}次后）：{last_error}',
            'text': self.full_text,
        }


# ============================================================
# Markdown → .docx 转换
# ============================================================

def markdown_to_docx(markdown_text, output_path, title='复习文档'):
    """
    将 DeepSeek 返回的 Markdown 文本转为 .docx 文件。

    支持的 Markdown 元素：
    - ### 一级标题 → Heading 1
    - #### 二级标题 → Heading 2
    - **粗体**
    - - 列表项
    - 普通段落
    - 表格（| 列 | 列 |）
    - 🔴 重点标记（保留 emoji）
    - ▶ 例题（保留格式）
    """
    if not HAS_DOCX:
        raise ImportError('缺少 python-docx 库。请运行：pip install python-docx')

    doc = Document()

    # 设置默认字体
    style = doc.styles['Normal']
    font = style.font
    font.name = '微软雅黑'
    font.size = Pt(10.5)
    from docx.oxml.ns import qn
    style.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')

    lines = markdown_text.strip().split('\n')

    # 合并被截断的表格行
    clean_lines = []
    in_table = False
    table_buffer = ''
    for line in lines:
        stripped = line.strip()
        if stripped.startswith('|') and (stripped.endswith('|') or '|' in stripped):
            if not in_table:
                in_table = True
                table_buffer = stripped
            else:
                table_buffer += '\n' + stripped
        else:
            if in_table:
                # 表格结束，把缓冲区作为一条
                clean_lines.append(table_buffer)
                table_buffer = ''
                in_table = False
            clean_lines.append(line)
    if table_buffer:
        clean_lines.append(table_buffer)

    for line in clean_lines:
        stripped = line.strip()

        if not stripped:
            # 空行→段落间距
            doc.add_paragraph()
            continue

        # --- 标题处理 ---
        if stripped.startswith('### '):
            heading_text = stripped[4:]
            p = doc.add_heading(heading_text, level=1)
            for run in p.runs:
                run.font.color.rgb = RGBColor(0x2C, 0x3E, 0x50)
            continue

        if stripped.startswith('#### '):
            heading_text = stripped[5:]
            p = doc.add_heading(heading_text, level=2)
            for run in p.runs:
                run.font.color.rgb = RGBColor(0x2C, 0x3E, 0x50)
            continue

        if stripped.startswith('##### '):
            heading_text = stripped[6:]
            p = doc.add_heading(heading_text, level=3)
            for run in p.runs:
                run.font.color.rgb = RGBColor(0x2C, 0x3E, 0x50)
            continue

        # --- 分隔线 ---
        if stripped in ('---', '───', '━━━', '════') or stripped.startswith('────────────────'):
            doc.add_paragraph('─' * 40)
            continue

        # --- 表格（含 | 分隔符） ---
        if '\n' in line and '|' in line:
            # 多行表格
            table_lines = line.split('\n')
            _insert_table(doc, table_lines)
            continue
        if stripped.startswith('|') and stripped.endswith('|'):
            _insert_table(doc, [stripped])
            continue

        # --- 普通段落 ---
        p = doc.add_paragraph()
        _add_formatted_text(p, stripped)
        p.paragraph_format.space_after = Pt(4)

    # 保存
    doc.save(output_path)
    return output_path


def _insert_table(doc, table_lines):
    """解析 ASCII 表格并插入到文档中"""
    rows_data = []
    for tl in table_lines:
        tl = tl.strip()
        if not tl:
            continue
        # 去掉首尾的 |
        if tl.startswith('|'):
            tl = tl[1:]
        if tl.endswith('|'):
            tl = tl[:-1]
        cells = [c.strip() for c in tl.split('|')]
        if cells:
            rows_data.append(cells)

    if len(rows_data) < 2:
        # 不够做一个表，就当成纯文本
        for row in rows_data:
            p = doc.add_paragraph()
            _add_formatted_text(p, ' | '.join(row))
        return

    # 第一行是表头，第二行可能是分隔行（---）
    header = rows_data[0]
    # 过滤掉分隔行（全是 - 的行）
    body = []
    for row in rows_data[1:]:
        if all('-' in c and len(c.replace('-','').replace(':','').strip()) == 0 for c in row):
            continue  # 这是分隔行
        body.append(row)

    if not body:
        return

    ncols = max(len(header), max(len(r) for r in body))
    table = doc.add_table(rows=1+len(body), cols=ncols)
    table.style = 'Light Grid Accent 1'

    # 表头
    for i, cell_text in enumerate(header):
        if i < ncols:
            cell = table.rows[0].cells[i]
            cell.text = cell_text
            for para in cell.paragraphs:
                for run in para.runs:
                    run.bold = True
                    run.font.size = Pt(9)

    # 数据行
    for r, row in enumerate(body):
        for c, cell_text in enumerate(row):
            if c < ncols:
                cell = table.rows[r+1].cells[c]
                cell.text = cell_text
                for para in cell.paragraphs:
                    for run in para.runs:
                        run.font.size = Pt(9)


def _add_formatted_text(paragraph, text):
    """向段落添加带格式的文字——处理 **粗体** """
    import re
    # 分割 **粗体**
    parts = re.split(r'(\*\*([^*]+)\*\*)', text)

    i = 0
    while i < len(parts):
        if parts[i].startswith('**') and parts[i].endswith('**'):
            # 粗体
            inner = parts[i][2:-2]
            run = paragraph.add_run(inner)
            run.bold = True
        elif parts[i] and not (i > 0 and parts[i-1] == f'**{parts[i]}**'):
            # 普通文本
            # 跳过已被粗体格式消耗的中间部分
            if i == 0 or parts[i-1] != f'**{parts[i]}**':
                pass
            run = paragraph.add_run(parts[i])
        i += 1

    # 简化版：直接用正则替换 **...** 为加粗
    # 清除段落并重建
    paragraph.clear()

    bold_pattern = re.compile(r'\*\*(.+?)\*\*')
    last_end = 0
    for match in bold_pattern.finditer(text):
        # 粗体前的普通文本
        if match.start() > last_end:
            run = paragraph.add_run(text[last_end:match.start()])
        # 粗体
        run = paragraph.add_run(match.group(1))
        run.bold = True
        last_end = match.end()
    # 剩余文本
    if last_end < len(text):
        paragraph.add_run(text[last_end:])


# ============================================================
# 便捷函数（供 GUI 调用）
# ============================================================

def generate_document(prompt, api_key, output_filename='复习文档', callback=None):
    """
    一站式：调 DeepSeek → 收 Markdown → 转 .docx → 存盘

    参数：
        prompt: 完整提示词（从 prompt_builder 来的）
        api_key: DeepSeek API Key
        output_filename: 输出文件名（不含扩展名）
        callback: dict of callbacks {
            'on_progress': fn(text_chunk),
            'on_status': fn(status_str),
        }

    返回：
        dict {
            'success': True/False,
            'docx_path': '.docx文件路径',
            'md_path': '原始Markdown路径',
            'error': '错误信息（仅失败时）',
            'tokens': 123,
        }
    """
    # 回调
    on_progress = callback.get('on_progress') if callback else None
    on_status = callback.get('on_status') if callback else None

    # 1 调 DeepSeek
    gen = DocGenerator(api_key)
    gen.set_callback(on_progress=on_progress, on_status=on_status)

    result = gen.generate(prompt, stream=True)

    if not result['success']:
        return {
            'success': False,
            'docx_path': '',
            'md_path': '',
            'error': result.get('error', '未知错误'),
        }

    markdown_text = result['text']

    # 2 保存原始 Markdown（debug + 用户可二次编辑）
    md_path = os.path.join(OUTPUT_DIR, output_filename + '.md')
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(markdown_text)

    if on_status:
        on_status('正在转换为 Word 文档...')

    # 3 Markdown → .docx
    docx_path = os.path.join(OUTPUT_DIR, output_filename + '.docx')
    markdown_to_docx(markdown_text, docx_path, title=output_filename)

    return {
        'success': True,
        'docx_path': docx_path,
        'md_path': md_path,
        'tokens': result.get('tokens_used', 0),
    }


# ============================================================
# 自测
# ============================================================
if __name__ == '__main__':
    print('=== doc_generator.py 自测 ===')
    print()

    # 检查依赖
    print(f'  openai: {"OK" if HAS_OPENAI else "MISSING"}')
    print(f'  python-docx: {"OK" if HAS_DOCX else "MISSING"}')
    print()

    # 检查 Key
    key = load_api_key()
    if key:
        print(f'  API Key: 已设置 ({key[:8]}...)')
    else:
        print('  API Key: 未设置（运行时需输入）')
    print()

    # 测试 Markdown→docx（不调 API，用本地假数据）
    test_md = """### 第一章：基本概念

#### 1.1 电流

电流是电荷的定向移动。单位：安培 A。

🔴 必背公式：I = U / R

▶ 例题1：已知 U=10V, R=5Ω，求 I。
【解】I = 10/5 = 2A。

| 概念 | 符号 | 单位 |
|------|------|------|
| 电压 | U | V |
| 电流 | I | A |
"""
    test_docx = os.path.join(OUTPUT_DIR, '_test_output.docx')
    try:
        markdown_to_docx(test_md, test_docx, '测试文档')
        size = os.path.getsize(test_docx)
        print(f'  测试 .docx 生成成功: {test_docx} ({size} bytes)')
        os.remove(test_docx)  # 清理测试文件
    except Exception as e:
        print(f'  测试失败: {e}')

    print()
    print('=== 自测完成 ===')
