# -*- coding: utf-8 -*-
"""
复习文档生成器 — 画图引擎
功能：根据学科和章节，自动生成配套示意图
      复用物理项目(21张) + 电路项目(22张)已验证的绘图代码
      新增数学/化学/生物/通用模板
创建日期：2026-06-27
"""

import os
import sys

# ============================================================
# matplotlib 必须最先设置
# ============================================================
import matplotlib
matplotlib.use('Agg')

import matplotlib.pyplot as plt
import numpy as np

from config import DIAGRAMS_DIR, COLORS, MPL_CONFIG, IMAGE_WIDTH_INCHES, IMAGE_FORMAT

# 全局字体设置
plt.rcParams.update(MPL_CONFIG)

# 配色别名
C = COLORS


# ============================================================
# 通用工具函数
# ============================================================

def save_fig(fig, name):
    """保存图片到 diagrams/ 目录"""
    path = os.path.join(DIAGRAMS_DIR, name)
    fig.savefig(path, dpi=MPL_CONFIG['savefig.dpi'],
                bbox_inches=MPL_CONFIG['savefig.bbox'],
                facecolor='white', edgecolor='none',
                pad_inches=MPL_CONFIG['savefig.pad_inches'])
    plt.close(fig)
    return path


def new_fig(w=7, h=5):
    """创建新图，返回 (fig, ax)"""
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 9)
    ax.axis('off')
    ax.set_aspect('equal')
    return fig, ax


def title(ax, text, y=8.5):
    """加标题"""
    ax.text(6, y, text, fontsize=14, ha='center', fontweight='bold', color=C['title'])


# ============================================================
# 通用绘图元件（矩形/箭头/圆圈/文字框）
# ============================================================

from matplotlib.patches import FancyBboxPatch, Circle, Polygon, Arc

def draw_box(ax, x, y, w, h, facecolor=C['main'], edgecolor=C['blue'], lw=2, text=''):
    """画圆角矩形"""
    box = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.1",
                          facecolor=facecolor, edgecolor=edgecolor, linewidth=lw)
    ax.add_patch(box)
    if text:
        ax.text(x+w/2, y+h/2, text, fontsize=10, ha='center', va='center', fontweight='bold')

def draw_arrow(ax, x1, y1, x2, y2, color=C['red'], lw=3, style='->', dashed=False):
    """画箭头"""
    kw = dict(arrowstyle=style, color=color, lw=lw)
    if dashed:
        kw['linestyle'] = 'dashed'
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1), arrowprops=kw)

def draw_label(ax, x, y, text, fontsize=10, color=C['dark'], bold=False, ha='center', bg=None):
    """画文字标签"""
    kw = dict(fontsize=fontsize, ha=ha, color=color)
    if bold:
        kw['fontweight'] = 'bold'
    if bg:
        kw['bbox'] = dict(boxstyle='round,pad=0.3', facecolor=bg, edgecolor='#F1C40F', alpha=0.8)
    ax.text(x, y, text, **kw)

def draw_circle(ax, x, y, r, facecolor='white', edgecolor=C['dark'], lw=2):
    """画圆"""
    c = Circle((x, y), r, facecolor=facecolor, edgecolor=edgecolor, linewidth=lw)
    ax.add_patch(c)
    return c

def draw_line(ax, x1, y1, x2, y2, color=C['dark'], lw=2, style='-'):
    ax.plot([x1, x2], [y1, y2], color=color, linewidth=lw, linestyle=style)


# ============================================================
# 物理图集（复用初二物理项目）
# ============================================================

def draw_physics_force():
    """力的三要素示意图——推箱子"""
    fig, ax = new_fig(7, 4.5)
    draw_box(ax, 3, 1.5, 2.5, 2, facecolor='#FFE4B5', edgecolor='#8B4513', text='箱子')
    ax.plot(3, 2.5, 'ko', markersize=8)
    draw_label(ax, 2.7, 2.8, '作用点', 9, C['dark'])
    draw_arrow(ax, 3.2, 2.5, 7.5, 2.5, C['red'], 3)
    draw_label(ax, 5.3, 2.9, 'F=50N', 11, C['red'], True)
    draw_label(ax, 5.3, 1.8, '方向：水平向右', 10, C['gray'])
    ax.axhline(y=1.5, xmin=0.1, xmax=0.9, color=C['gray'], linewidth=3)
    title(ax, '力的三要素：大小·方向·作用点', 5.5)
    draw_label(ax, 6, 4.8, '力的示意图 = 带箭头的线段', 11, C['gray'], False)
    return save_fig(fig, '01_力的示意图.png')

def draw_physics_gravity():
    """重力示意图——小车"""
    fig, ax = new_fig(7, 5)
    ax.axhline(y=1, color=C['gray'], lw=3)
    draw_box(ax, 3, 2.5, 4, 1.5, '#AED6F1', '#2E86C1', text=f'小车 m=1500kg')
    for cx in [4, 6.5]:
        draw_circle(ax, cx, 2, 0.5, '#333', '#111')
    draw_arrow(ax, 5, 3.1, 5, 0.3, C['red'], 4)
    draw_label(ax, 4.2, 1.6, 'G=mg=15000N\n(竖直向下)', 10, C['red'], True)
    ax.plot(5, 3.1, 'ro', markersize=8)
    draw_label(ax, 5.4, 3.4, '重心', 10, C['red'])
    title(ax, '重力 — 方向：竖直向下', 7.5)
    draw_label(ax, 6, 6.8, 'G = mg    g = 10N/kg', 12, C['red'], True, bg=C['bg_yellow'])
    return save_fig(fig, '02_重力示意图.png')

def draw_physics_elastic():
    """弹力——弹簧拉长/压缩"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5))
    for ax, ti, inward in [(ax1, '弹簧被拉长 → 弹力向内缩', True),
                            (ax2, '弹簧被压缩 → 弹力向外推', False)]:
        ax.set_xlim(0,10); ax.set_ylim(0,10); ax.axis('off'); ax.set_aspect('equal')
        ax.set_title(ti, fontsize=12, fontweight='bold', color=C['title'])
        # 天花板
        ax.axhline(y=9.5, xmin=0.3, xmax=0.7, color=C['gray'], lw=3)
        # 弹簧锯齿线
        n = 16 if inward else 12
        sy, ey = 4, 9.5
        xs = [5.2 - 0.3*(-1)**i for i in range(n)]
        ys = np.linspace(ey, sy, n) if inward else np.linspace(ey, 5.5, n)
        ax.plot(xs, ys, color=C['gray'], linewidth=2)
        # 重物
        draw_box(ax, 4, 2.5, 2, 1.5, '#F5B7B1', '#C0392B', text='G')
        # 弹力箭头
        if inward:
            draw_arrow(ax, 5, 5, 5, 8.5, C['blue'], 3)
            draw_label(ax, 5.8, 6.5, '弹力向上\n(恢复原状)', 10, C['blue'])
        else:
            draw_arrow(ax, 5, 5.2, 5, 3.2, C['blue'], 3)
            draw_label(ax, 5.8, 3.8, '弹力向下\n(向外推)', 10, C['blue'])
    plt.suptitle('弹力：方向总是与形变方向相反', fontsize=14, fontweight='bold', color=C['title'], y=1.02)
    return save_fig(fig, '03_弹力示意图.png')

def draw_physics_balance():
    """二力平衡——书放在桌上"""
    fig, ax = new_fig(7, 5)
    ax.axhline(y=3, color='#DEB887', lw=8, alpha=0.5)
    draw_box(ax, 3.5, 3, 3, 0.8, '#D5F5E3', '#27AE60', text='书  G=3N')
    draw_arrow(ax, 5, 3, 5, 2, C['red'], 4)
    draw_label(ax, 4.2, 2.3, '重力 G ↓', 11, C['red'], True)
    draw_arrow(ax, 5, 3.8, 5, 5.5, C['blue'], 4)
    draw_label(ax, 4.2, 5.5, '支持力 F ↑', 11, C['blue'], True)
    for i, c in enumerate(['① 同体——都作用在书上','② 等大——G=F(书静止)','③ 反向——一个↓一个↑','④ 共线——都在竖直方向']):
        draw_label(ax, 6, 7.2-i*0.45, c, 10, C['dark'], bg=C['bg_yellow'])
    title(ax, '二力平衡: 同体·等大·反向·共线')
    return save_fig(fig, '04_二力平衡.png')

def draw_physics_friction():
    """摩擦力——静摩擦 vs 滑动摩擦"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 5))
    for ax, ti, moving in [(ax1, '静摩擦力（推不动）', False), (ax2, '滑动摩擦力（匀速）', True)]:
        ax.set_xlim(0,10); ax.set_ylim(0,8); ax.axis('off')
        ax.set_title(ti, fontsize=12, fontweight='bold', color=C['title'])
        ax.axhline(y=1.5, color=C['gray'], lw=3)
        draw_box(ax, 3, 1.5, 2.5, 2, '#FFE4B5', '#8B4513', text=f'箱子\n{moving and "100" or "50"}N')
        draw_arrow(ax, 6.5, 2.5, 5.5, 2.5, C['red'], 3)
        draw_label(ax, 7, 2.8, 'F=30N', 11, C['red'], True)
        draw_arrow(ax, 2.2, 2.5, 3.5, 2.5, C['blue'], 3)
        tag_text = 'f=30N (滑动摩擦)' if moving else 'f=30N (静摩擦)'
        draw_label(ax, 0.5, 2.8, tag_text, 10, C['blue'], True)
        note = '匀速 → f=F' if moving else '箱子静止 → f=F\n推力多大摩擦就多大'
        draw_label(ax, 4.25, 5.5, note, 10, C['dark'], bg=C['bg_green'])
    plt.suptitle('摩擦力：「匀速/静止」 → 受力平衡 → 合力为零', fontsize=14, fontweight='bold', color=C['title'], y=1.02)
    return save_fig(fig, '05_摩擦力示意图.png')


# ============================================================
# 电路图集（复用电路基础项目）
# ============================================================

def draw_circuit_resistor(ax, x, y, w=1.5, h=0.4, label='R'):
    """锯齿形电阻"""
    n, xs = 6, np.linspace(x, x+w, 12)
    ys = [y+(h if i%2==0 else -h) for i in range(12)]
    ax.plot(xs, ys, color=C['dark'], linewidth=2)
    ax.text(x+w/2, y-h*2.5, label, fontsize=10, ha='center', color=C['dark'], fontweight='bold')

def draw_circuit_vsource(ax, x, y, r=0.4, label='US'):
    """独立电压源"""
    draw_circle(ax, x, y, r, 'white', C['red'])
    ax.text(x, y+r+0.15, '+', fontsize=8, ha='center', color=C['red'], fontweight='bold')
    ax.text(x, y-r-0.35, '-', fontsize=8, ha='center', color=C['red'], fontweight='bold')
    ax.text(x, y-r-0.7, label, fontsize=9, ha='center', color=C['red'], fontweight='bold')

def draw_circuit_wire(ax, points):
    xs, ys = zip(*points)
    ax.plot(xs, ys, color=C['dark'], linewidth=2)

def draw_circuit_node(ax, x, y):
    ax.plot(x, y, 'o', color=C['red'], markersize=6, zorder=5)

def draw_circuit_kcl():
    """KCL节点示意图"""
    fig, ax = new_fig(7, 5)
    draw_circuit_node(ax, 6, 4.5)
    draw_label(ax, 6, 4.1, '节点A', 11, C['red'], True)
    arrows = [(3, 4.5, 'I1=3A 入', C['blue']),(6, 7, 'I2=5A 入', C['blue']),
              (9, 4.5, 'I3=2A 出', C['green']),(6, 2, 'I4=?', C['red'])]
    for x, y, label, color in arrows:
        draw_arrow(ax, x, y, 6, 4.5, color, 2)
        draw_label(ax, x, y+0.5 if y>4.5 else y-0.6, label, 10, color, True)
    draw_label(ax, 6, 8, 'KCL: I1+I2+I3+I4=0', 14, C['dark'], True, bg=C['bg_yellow'])
    draw_label(ax, 6, 7.3, '3+5-2-I4=0 → I4=6A(流出)', 12, C['red'], True)
    return save_fig(fig, '21_KCL节点.png')

def draw_circuit_kvl():
    """KVL回路示意图"""
    fig, ax = new_fig(8, 5)
    points = [(2,6),(3,6),(5,6),(6,6),(8,6),(9,6),(9,2),(2,2),(2,6)]
    draw_circuit_wire(ax, points)
    draw_circuit_resistor(ax, 3, 6, 1.5, 0.35, 'R1=2Ω')
    draw_circuit_resistor(ax, 6, 6, 1.5, 0.35, 'R2=3Ω')
    draw_circuit_vsource(ax, 9, 3, 0.4, 'US=10V')
    draw_label(ax, 5.5, 8, 'KVL: -US + I*R1 + I*R2 = 0', 14, C['dark'], True, bg=C['bg_yellow'])
    draw_label(ax, 5.5, 7.2, '-10+2I+3I=0 → I=2A', 12, C['red'], True)
    return save_fig(fig, '22_KVL回路.png')

def draw_circuit_thevenin():
    """戴维南定理三步走"""
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(13, 4.5))
    for ax, ti in [(ax1,'Step1: 求Uoc'),(ax2,'Step2: 求Req'),(ax3,'Step3: 等效')]:
        ax.set_xlim(0,8); ax.set_ylim(0,7); ax.axis('off')
        ax.set_title(ti, fontsize=11, fontweight='bold', color=C['red'])
    draw_box(ax1, 1, 1.5, 5, 4.5, C['main'], C['blue'], text='含源\n线性\n网络')
    draw_circuit_node(ax1, 6, 4); ax1.text(6, 4.5, 'a', fontsize=11, ha='center', color=C['red'], fontweight='bold')
    draw_circuit_node(ax1, 6, 2.5); ax1.text(6, 2, 'b', fontsize=11, ha='center', color=C['red'], fontweight='bold')
    draw_arrow(ax1, 7.5, 4, 7.5, 2.5, C['red'], 2); ax1.text(8, 3.25, 'Uoc', fontsize=11, color=C['red'], fontweight='bold')
    draw_box(ax2, 1, 1.5, 5, 4.5, C['bg_green'], C['green'], text='独立源\n全部置零\n(受控源保留)')
    draw_circuit_node(ax2, 6, 4); draw_circuit_node(ax2, 6, 2.5)
    draw_arrow(ax2, 7.5, 4, 7.5, 2.5, C['blue'], 2); ax2.text(8, 3.25, 'Req', fontsize=11, color=C['blue'], fontweight='bold')
    draw_circuit_vsource(ax3, 4, 5, 0.4, 'Uoc')
    draw_circuit_resistor(ax3, 4, 3.5, 1.5, 0.25, 'Req')
    draw_circuit_wire(ax3, [(4,5.5),(5,5.5),(5,2.5),(2,2.5),(2,3.5),(3.5,3.5)])
    draw_circuit_wire(ax3, [(3,5.5),(4,5.5)])
    draw_circuit_node(ax3, 5, 5.5); ax3.text(5, 6, 'a', fontsize=11, ha='center', color=C['red'], fontweight='bold')
    draw_circuit_node(ax3, 5, 2.5); ax3.text(5, 2, 'b', fontsize=11, ha='center', color=C['red'], fontweight='bold')
    draw_label(ax3, 5.8, 4, 'RL', 11, C['blue'])
    plt.suptitle('戴维南定理三步走', fontsize=14, fontweight='bold', color=C['title'], y=1.03)
    return save_fig(fig, '23_戴维南定理.png')


# ============================================================
# 数学图集
# ============================================================

def draw_math_function():
    """二次函数图像——开口方向+对称轴+顶点"""
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.set_xlim(-4, 4); ax.set_ylim(-2, 8)
    ax.axhline(y=0, color=C['gray'], lw=0.5); ax.axvline(x=0, color=C['gray'], lw=0.5)
    ax.grid(True, alpha=0.3)
    x = np.linspace(-3.5, 3.5, 200)
    y = x**2 - 2*x - 1
    ax.plot(x, y, C['red'], lw=2.5)
    ax.axvline(x=1, color=C['blue'], linestyle='--', lw=1.5)
    ax.plot(1, -2, 'o', color=C['red'], markersize=8)
    ax.text(1.2, -2.5, '顶点(1,-2)', fontsize=10, color=C['red'], fontweight='bold')
    ax.text(2.5, 5, 'y=x²-2x-1', fontsize=12, color=C['red'], fontweight='bold',
            bbox=dict(boxstyle='round', facecolor=C['bg_yellow'], edgecolor='#F1C40F'))
    ax.text(1.1, 7, '对称轴 x=1', fontsize=10, color=C['blue'])
    ax.set_title('二次函数图像', fontsize=14, fontweight='bold', color=C['title'])
    return save_fig(fig, '24_函数图像.png')

def draw_math_geometry():
    """几何辅助线——三角形全等判定"""
    fig, ax = new_fig(7, 5)
    # 三角形
    tri = [(2,2),(7,2),(4.5,6)]
    from matplotlib.patches import Polygon as MPolygon
    t = MPolygon(tri, closed=True, facecolor=C['main'], edgecolor=C['blue'], linewidth=2, alpha=0.5)
    ax.add_patch(t)
    for x,y,l in [(2,2,'A'),(7,2,'B'),(4.5,6,'C')]:
        ax.plot(x, y, 'o', color=C['red'], markersize=6)
        ax.text(x-0.3, y-0.4, l, fontsize=12, color=C['red'], fontweight='bold')
    # 辅助线（中线）
    ax.plot([4.5, 6], [4, 2], C['green'], linestyle='--', lw=2)
    draw_label(ax, 5.5, 3.2, '辅助线', 9, C['green'])
    title(ax, '几何证明——辅助线示意图', 7.5)
    draw_label(ax, 4.5, 1, '全等三角形 SSS/SAS/ASA/AAS', 11, C['dark'], True, bg=C['bg_yellow'])
    return save_fig(fig, '25_几何辅助线.png')


# ============================================================
# 化学图集
# ============================================================

def draw_chemistry_apparatus():
    """化学实验装置示意图"""
    fig, ax = new_fig(6, 7)
    # 铁架台
    ax.plot([3, 3], [1, 7.5], C['dark'], lw=2)
    ax.plot([2, 4], [1, 1], C['dark'], lw=3)
    # 圆底烧瓶
    from matplotlib.patches import Ellipse
    flask = Ellipse((3, 4), 2, 3, facecolor=C['main'], edgecolor=C['blue'], linewidth=2, alpha=0.4)
    ax.add_patch(flask)
    # 液体
    ax.fill_between([2.2, 3.8], [3, 3], [2.5, 2.5], color='#85C1E9', alpha=0.6)
    # 导管
    ax.plot([4, 6], [5, 6], C['dark'], lw=2)
    ax.plot([6, 6], [6, 4.5], C['dark'], lw=2)
    # 试管
    ax.plot([5.5, 6.5], [3, 3], C['dark'], lw=2)
    ax.plot([5.5, 5.5], [3, 4.5], C['dark'], lw=2)
    ax.plot([6.5, 6.5], [3, 4.5], C['dark'], lw=2)
    # 酒精灯
    ax.fill_between([2.5, 3.5], [2.2, 2.2], [1.8, 1.8], color='#FADBD8', alpha=0.8)
    draw_label(ax, 3, 1.5, '△ 加热', 9, C['red'])
    # 标注
    draw_label(ax, 1.5, 7, '铁架台', 9, C['dark'])
    draw_label(ax, 4.5, 4, '圆底烧瓶', 9, C['dark'])
    draw_label(ax, 7, 5.5, '导管', 9, C['dark'])
    draw_label(ax, 7, 3.5, '试管', 9, C['dark'])
    title(ax, '化学实验装置示意图', 8.5)
    return save_fig(fig, '26_化学实验装置.png')

def draw_chemistry_flow():
    """化学反应流程图"""
    fig, ax = new_fig(10, 4)
    steps = ['反应物\nA + B', '加热/催化', '中间产物\n过渡态', '冷却结晶', '生成物\nC + D']
    xs = [1.5, 3.5, 5.5, 7.5, 9.5]
    for i, (x, s) in enumerate(zip(xs, steps)):
        c = [C['main'], C['orange'], C['bg_yellow'], C['bg_green'], C['main']][i]
        draw_box(ax, x-0.8, 2, 1.6, 2, c, C['blue'], text=s)
        if i < 4:
            draw_arrow(ax, x+0.8, 3, x+1.6, 3, C['red'], 2.5)
    title(ax, '化学反应流程图', 8)
    return save_fig(fig, '27_化学反应流程.png')


# ============================================================
# 通用图集（学习路径+考点分布）
# ============================================================

def draw_learning_path():
    """一周学习路径图"""
    fig, ax = new_fig(11, 6)
    stages = [('Day1-2\n基础', C['green']),('Day3\nKCL/KVL', C['blue']),
              ('Day4\n等效变换', C['blue']),('Day5\n分析方法', C['orange']),
              ('Day6\n电路定理', C['red']),('Day7\n综合突破', C['red'])]
    for i, (label, color) in enumerate(stages):
        x = 2 + i*1.8
        draw_box(ax, x-0.7, 3.5, 1.4, 1.4, color, '#333', text=label)
        ax.text(x, 3.5, label, fontsize=8, ha='center', va='center', color='white', fontweight='bold')
        if i < 5:
            draw_arrow(ax, x+0.7, 4.2, x+1.1, 4.2, C['gray'], 2)
    title(ax, '一周冲刺90分学习路径', 8.5)
    draw_label(ax, 6, 1.5, '每天3-4小时：看讲解(40%) + 做例题(50%) + 查漏(10%)', 12, C['gray'], False)
    return save_fig(fig, '28_学习路径.png')

def draw_exam_tips():
    """高频考点分布图"""
    fig, ax = new_fig(9, 6)
    tips = [('基础概念', '占选择判断30%\n物理本质必考', C['green']),
            ('核心定律', '计算大题核心\nKCL/KVL/欧姆', C['red']),
            ('分析方法', '多源电路求解\n节点法/网孔法', C['blue']),
            ('电路定理', '戴维南/诺顿\n期末必出大题', C['orange'])]
    for i, (name, desc, color) in enumerate(tips):
        x = 2 + (i % 2)*5
        y = 6 if i < 2 else 2.5
        draw_box(ax, x-1.5, y-1, 3, 2, 'white', color, lw=2.5, text='')
        ax.text(x, y+0.3, name, fontsize=12, ha='center', color=color, fontweight='bold')
        ax.text(x, y-0.4, desc, fontsize=9, ha='center', color=C['gray'])
    title(ax, '高频考点速览', 8.5)
    return save_fig(fig, '29_考点分布.png')


# ============================================================
# 学科→画图函数 映射表
# ============================================================

SUBJECT_DIAGRAM_FUNCTIONS = {
    '物理': [
        draw_physics_force, draw_physics_gravity, draw_physics_elastic,
        draw_physics_balance, draw_physics_friction,
    ],
    '电路基础': [
        draw_circuit_kcl, draw_circuit_kvl, draw_circuit_thevenin,
    ],
    '数学': [
        draw_math_function, draw_math_geometry,
    ],
    '化学': [
        draw_chemistry_apparatus, draw_chemistry_flow,
    ],
    # 通用图——任何学科都需要
    '_通用': [
        draw_learning_path, draw_exam_tips,
    ],
}


# ============================================================
# 主编排函数
# ============================================================

def generate_diagrams(subject, chapters=None):
    """
    根据学科生成所有配套示意图。

    参数：
        subject: str — "物理"/"电路基础"/"数学"/"化学" 等
        chapters: str or list — 章节信息（用于匹配，当前版本忽略）

    返回：
        list of str — 生成的所有图片文件路径
    """
    paths = []

    # 精确匹配
    funcs = SUBJECT_DIAGRAM_FUNCTIONS.get(subject, [])

    # 子串匹配（如 "初中物理" 应匹配 "物理"）
    if not funcs:
        for key in SUBJECT_DIAGRAM_FUNCTIONS:
            if key in subject or subject in key:
                funcs = SUBJECT_DIAGRAM_FUNCTIONS[key]
                break

    # 如果还没匹配到，只生成通用图
    if not funcs:
        print(f'  [DiagramGenerator] 学科 "{subject}" 无专属配图模板，只生成通用图。')

    # 加通用图
    funcs = funcs + SUBJECT_DIAGRAM_FUNCTIONS['_通用']

    for func in funcs:
        try:
            path = func()
            paths.append(path)
            print(f'  OK {os.path.basename(path)}')
        except Exception as e:
            print(f'  FAIL {func.__name__}: {e}')

    return paths


# ============================================================
# 自测
# ============================================================
if __name__ == '__main__':
    print('=== diagram_generator.py 自测 ===')
    print()

    print('[物理]')
    physics_paths = generate_diagrams('物理')
    print(f'  生成 {len(physics_paths)} 张图')

    print()
    print('[电路基础]')
    circuit_paths = generate_diagrams('电路基础')
    print(f'  生成 {len(circuit_paths)} 张图')

    print()
    print('[数学]')
    math_paths = generate_diagrams('数学')
    print(f'  生成 {len(math_paths)} 张图')

    print()
    print('[化学]')
    chem_paths = generate_diagrams('化学')
    print(f'  生成 {len(chem_paths)} 张图')

    print()
    print(f'总计: {len(physics_paths) + len(circuit_paths) + len(math_paths) + len(chem_paths)} 张图')
    print(f'存放位置: {DIAGRAMS_DIR}')
    print()
    print('=== 自测完成 ===')
