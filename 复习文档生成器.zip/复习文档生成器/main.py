# -*- coding: utf-8 -*-
"""
复习文档生成器 — GUI 主窗口
一键式：填表 → 点按钮 → 出 .docx
创建日期：2026-06-27
"""

import os
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

# 自己的模块
from config import SCHOOL_LEVELS, SEMESTERS, DIFFICULTY_LEVELS, OUTPUT_DIR
from prompt_builder import build_prompt
from doc_generator import generate_document, load_api_key, save_api_key, SETTINGS_FILE
from diagram_generator import generate_diagrams
from doc_assembler import assemble_document


# ============================================================
# GUI 类
# ============================================================

class ReviewDocApp:
    def __init__(self, root):
        self.root = root
        self.root.title('复习文档生成器 v1.0')
        self.root.geometry('700x720')
        self.root.resizable(True, True)

        # 状态变量
        self.api_key = tk.StringVar(value=load_api_key())
        self.school_level = tk.StringVar(value='初中')
        self.grade = tk.StringVar(value='初二')
        self.semester = tk.StringVar(value='下册')
        self.subject = tk.StringVar(value='物理')
        self.chapters = tk.StringVar(value='')
        self.difficulty = tk.StringVar(value='base')
        self.with_diagrams = tk.BooleanVar(value=True)
        self.output_name = tk.StringVar(value='')

        self.is_generating = False

        # 构建界面
        self._build_ui()

        # 启动时检查 API Key
        if not self.api_key.get():
            self.root.after(500, self._ask_api_key)

    # ============================================================
    # UI 构建
    # ============================================================

    def _build_ui(self):
        main_frame = ttk.Frame(self.root, padding='10')
        main_frame.pack(fill=tk.BOTH, expand=True)

        # ---- 标题 ----
        title_label = ttk.Label(main_frame,
                                text='📋 复习文档生成器',
                                font=('Microsoft YaHei', 16, 'bold'))
        title_label.pack(pady=(0, 2))

        subtitle = ttk.Label(main_frame,
                             text='填表 → 一键生成带配图的 Word 复习文档',
                             font=('Microsoft YaHei', 9))
        subtitle.pack(pady=(0, 10))

        # ---- 表单区域（用LabelFrame分组） ----
        form_frame = ttk.Frame(main_frame)
        form_frame.pack(fill=tk.X, pady=5)

        # 第一行：学段 + 年级 + 学期
        row1 = ttk.Frame(form_frame)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text='学段:', width=8).pack(side=tk.LEFT)
        self._make_combo(row1, self.school_level,
                         list(SCHOOL_LEVELS.keys()),
                         width=8, callback=self._on_school_changed).pack(side=tk.LEFT, padx=(0, 10))

        ttk.Label(row1, text='年级:', width=8).pack(side=tk.LEFT)
        self.grade_combo = self._make_combo(row1, self.grade,
                                            SCHOOL_LEVELS['初中']['grades'], width=8)
        self.grade_combo.pack(side=tk.LEFT, padx=(0, 10))

        ttk.Label(row1, text='学期:', width=8).pack(side=tk.LEFT)
        self._make_combo(row1, self.semester, SEMESTERS, width=8).pack(side=tk.LEFT)

        # 第二行：学科 + 输出文件名
        row2 = ttk.Frame(form_frame)
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text='学科:', width=8).pack(side=tk.LEFT)
        self.subject_combo = self._make_combo(row2, self.subject,
                                              SCHOOL_LEVELS['初中']['subjects'], width=15)
        self.subject_combo.pack(side=tk.LEFT, padx=(0, 10))

        ttk.Label(row2, text='文件名:', width=8).pack(side=tk.LEFT)
        name_entry = ttk.Entry(row2, textvariable=self.output_name, width=25)
        name_entry.pack(side=tk.LEFT)
        ttk.Label(row2, text='(留空自动命名)', font=('', 8)).pack(side=tk.LEFT, padx=5)

        # 第三行：章节
        row3 = ttk.Frame(form_frame)
        row3.pack(fill=tk.X, pady=2)
        ttk.Label(row3, text='章节:', width=8).pack(side=tk.LEFT)
        chapter_entry = ttk.Entry(row3, textvariable=self.chapters, width=60)
        chapter_entry.pack(side=tk.LEFT)
        ttk.Label(row3, text='例：第七~十二章', font=('', 8)).pack(side=tk.LEFT, padx=5)

        # 第四行：难度
        row4 = ttk.Frame(form_frame)
        row4.pack(fill=tk.X, pady=2)
        ttk.Label(row4, text='难度:', width=8).pack(side=tk.LEFT)
        for key, info in DIFFICULTY_LEVELS.items():
            rb = ttk.Radiobutton(row4, text=info['label'], variable=self.difficulty, value=key)
            rb.pack(side=tk.LEFT, padx=(0, 10))

        # 第五行：开关
        row5 = ttk.Frame(form_frame)
        row5.pack(fill=tk.X, pady=2)
        ttk.Checkbutton(row5, text='生成配图（Python matplotlib 原创，自动插入 Word）',
                        variable=self.with_diagrams).pack(side=tk.LEFT)

        # ---- API Key ----
        api_frame = ttk.LabelFrame(main_frame, text='DeepSeek API Key', padding='5')
        api_frame.pack(fill=tk.X, pady=5)
        api_row = ttk.Frame(api_frame)
        api_row.pack(fill=tk.X)
        self.api_entry = ttk.Entry(api_row, textvariable=self.api_key, show='*', width=50)
        self.api_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(api_row, text='保存', command=self._save_key, width=6).pack(side=tk.LEFT, padx=5)
        ttk.Button(api_row, text='去获取 Key', command=self._open_deepseek_url, width=10).pack(side=tk.LEFT)
        ttk.Label(api_frame, text='Key 仅存本机，不联网上传。去 platform.deepseek.com/api_keys 获取',
                  font=('', 7), foreground='gray').pack(anchor='w')

        # ---- 进度条 ----
        progress_frame = ttk.Frame(main_frame)
        progress_frame.pack(fill=tk.X, pady=5)
        self.progress = ttk.Progressbar(progress_frame, mode='indeterminate')
        self.progress.pack(fill=tk.X, side=tk.LEFT, expand=True)
        self.cancel_btn = ttk.Button(progress_frame, text='取消', command=self._cancel,
                                     state=tk.DISABLED, width=6)
        self.cancel_btn.pack(side=tk.RIGHT, padx=(5, 0))

        # ---- 状态 ----
        self.status_label = ttk.Label(main_frame, text='就绪', font=('', 9), foreground='gray')
        self.status_label.pack(anchor='w')

        # ---- 输出预览（可滚动） ----
        output_frame = ttk.LabelFrame(main_frame, text='生成预览', padding='3')
        output_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.output_text = scrolledtext.ScrolledText(output_frame, height=12,
                                                     font=('Microsoft YaHei', 9),
                                                     wrap=tk.WORD)
        self.output_text.pack(fill=tk.BOTH, expand=True)
        self.output_text.insert(tk.END, '此处将实时显示 AI 生成的文档文字...\n')
        self.output_text.config(state=tk.DISABLED)

        # ---- 按钮区 ----
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=5)

        self.gen_btn = ttk.Button(btn_frame, text='▶ 一键生成文档',
                                  command=self._start_generate, width=20)
        self.gen_btn.pack(side=tk.LEFT, padx=(0, 10))

        ttk.Button(btn_frame, text='打开输出文件夹',
                   command=self._open_output_dir, width=14).pack(side=tk.LEFT)

        ttk.Button(btn_frame, text='关于',
                   command=self._about, width=8).pack(side=tk.RIGHT)

    # ============================================================
    # 工具方法
    # ============================================================

    def _make_combo(self, parent, variable, values, width=12, callback=None):
        cb = ttk.Combobox(parent, textvariable=variable, values=values,
                          state='readonly', width=width)
        if callback:
            cb.bind('<<ComboboxSelected>>', callback)
        return cb

    def _on_school_changed(self, event=None):
        """学段切换时，更新年级和学科下拉列表"""
        level = self.school_level.get()
        info = SCHOOL_LEVELS.get(level, {})
        grades = info.get('grades', [])
        subjects = info.get('subjects', [])

        self.grade_combo['values'] = grades
        self.subject_combo['values'] = subjects

        if grades:
            self.grade.set(grades[0])
        if subjects:
            self.subject.set(subjects[0])

        # 自动填章节占位
        if not self.chapters.get():
            hints = {'小学': '第一~八单元', '初中': '第七~十二章',
                     '高中': '第一~五章', '大学': '第一章~第六章'}
            self.chapters.set(hints.get(level, ''))

    def _set_status(self, text, color='gray'):
        self.status_label.config(text=text, foreground=color)
        self.root.update_idletasks()

    def _set_progress(self, running):
        if running:
            self.progress.start(10)
        else:
            self.progress.stop()
        self.cancel_btn.config(state=tk.NORMAL if running else tk.DISABLED)
        self.gen_btn.config(state=tk.DISABLED if running else tk.NORMAL)

    def _append_output(self, text):
        self.output_text.config(state=tk.NORMAL)
        self.output_text.insert(tk.END, text)
        self.output_text.see(tk.END)
        self.output_text.config(state=tk.DISABLED)

    def _clear_output(self):
        self.output_text.config(state=tk.NORMAL)
        self.output_text.delete('1.0', tk.END)
        self.output_text.config(state=tk.DISABLED)

    # ============================================================
    # API Key
    # ============================================================

    def _ask_api_key(self):
        ok = messagebox.askyesno(
            '需要 DeepSeek API Key',
            '检测到没有保存的 API Key。\n\n'
            '生成文档需要调用 DeepSeek 来写文字内容。\n'
            '去 platform.deepseek.com/api_keys 免费获取一个 Key。\n\n'
            '费用：生成一份完整复习文档约 ¥0.5-1 元。\n\n'
            '点击"是"去获取，然后粘贴到 API Key 输入框。'
        )
        if ok:
            self._open_deepseek_url()

    def _save_key(self):
        key = self.api_key.get().strip()
        if key:
            if not key.startswith('sk-'):
                messagebox.showwarning('格式检查', 'DeepSeek Key 通常以 sk- 开头。请确认 Key 正确。')
            save_api_key(key)
            self._set_status('API Key 已保存到 settings.json', 'green')
        else:
            self._set_status('API Key 为空，未保存', 'red')

    def _open_deepseek_url(self):
        import webbrowser
        webbrowser.open('https://platform.deepseek.com/api_keys')

    # ============================================================
    # 生成主流程（后台线程）
    # ============================================================

    def _start_generate(self):
        """入口：校验输入 → 启后台线程"""
        # 校验
        if not self.api_key.get().strip():
            messagebox.showwarning('缺少 API Key',
                                   '请先输入 DeepSeek API Key。\n去 platform.deepseek.com/api_keys 免费获取。')
            return

        if not self.subject.get().strip():
            messagebox.showwarning('缺少学科', '请输入学科名称。')
            return

        school = self.school_level.get()
        grade = self.grade.get()
        semester = self.semester.get()
        subject = self.subject.get().strip()
        chapters = self.chapters.get().strip() or '按教材默认章节'
        difficulty = self.difficulty.get()
        with_diagrams = self.with_diagrams.get()

        # 自动生成文件名
        output_name = self.output_name.get().strip()
        if not output_name:
            output_name = f'{grade}{semester}{subject}-复习完全指南'

        # 禁用按钮，启动进度条
        self._set_progress(True)
        self._clear_output()
        self._append_output(f'=== 开始生成：{output_name} ===\n')
        self._append_output(f'学段：{school} | 学科：{subject} | 难度：{DIFFICULTY_LEVELS[difficulty]["label"]}\n')
        self._append_output(f'配图：{"是" if with_diagrams else "否"}\n\n')

        # 后台线程
        thread = threading.Thread(
            target=self._run_generate,
            args=(school, grade, semester, subject, chapters, difficulty, with_diagrams, output_name),
            daemon=True
        )
        thread.start()

    def _run_generate(self, school, grade, semester, subject, chapters, difficulty, with_diagrams, output_name):
        """生成主流程（在后台线程中运行）"""
        api_key = self.api_key.get().strip()
        final_path = ''
        try:
            # ── Phase 1: 组装提示词 ──
            self.root.after(0, lambda: self._set_status('正在组装提示词...', 'blue'))
            self.root.after(0, lambda: self._append_output('[1/4] 组装提示词...\n'))
            prompt = build_prompt(school, grade, semester, subject, chapters, difficulty, with_diagrams)
            self.root.after(0, lambda: self._append_output(f'      提示词 {len(prompt)} 字符\n\n'))

            # ── Phase 2: 调 DeepSeek 生成文字 ──
            self.root.after(0, lambda: self._set_status('正在生成文档文字（DeepSeek）...', 'blue'))
            self.root.after(0, lambda: self._append_output('[2/4] 调用 DeepSeek 生成文档文字...\n'))

            # 回调：实时显示生成文字
            def on_chunk(text):
                self.root.after(0, lambda t=text: self._append_output(t))
                if self.is_generating is False:  # 仅用于触发检查——实际用 cancel
                    pass

            def on_status(msg):
                self.root.after(0, lambda m=msg: self._set_status(m, 'blue'))

            result = generate_document(
                prompt=prompt,
                api_key=api_key,
                output_filename=output_name + '_文字版',
                callback={'on_progress': on_chunk, 'on_status': on_status},
            )

            if not result['success']:
                self.root.after(0, lambda: self._set_status(f'失败：{result["error"]}', 'red'))
                self.root.after(0, lambda: self._append_output(f'\n❌ 失败：{result["error"]}\n'))
                self.root.after(0, lambda: self._set_progress(False))
                return

            text_docx_path = result['docx_path']
            self.root.after(0, lambda: self._append_output(
                f'\n      文字文档已生成：{os.path.basename(text_docx_path)}\n\n'))

            # ── Phase 3: 画图 ──
            if with_diagrams:
                self.root.after(0, lambda: self._set_status('正在生成配图...', 'blue'))
                self.root.after(0, lambda: self._append_output('[3/4] 生成配图...\n'))
                diagram_paths = generate_diagrams(subject, chapters)
                self.root.after(0, lambda: self._append_output(f'      生成 {len(diagram_paths)} 张图\n\n'))
            else:
                diagram_paths = []
                self.root.after(0, lambda: self._append_output('[3/4] 跳过（未开启配图）\n\n'))

            # ── Phase 4: 拼装最终文档 ──
            self.root.after(0, lambda: self._set_status('正在拼装最终文档...', 'blue'))
            self.root.after(0, lambda: self._append_output('[4/4] 拼装最终文档（文字 + 配图）...\n'))

            if diagram_paths:
                ass_result = assemble_document(text_docx_path, output_name, subject)
                if ass_result['success']:
                    final_path = ass_result['output_path']
                    self.root.after(0, lambda: self._append_output(
                        f'      插入 {ass_result["images_inserted"]} 张配图\n'))
                else:
                    # 配图插入失败但文字还在——把文字版当最终版
                    final_path = text_docx_path
                    self.root.after(0, lambda: self._append_output(
                        f'      ⚠️ 配图插入失败：{ass_result.get("error")}，使用文字版\n'))
            else:
                final_path = text_docx_path

            # ── 完成 ──
            self.root.after(0, lambda: self._set_status('✅ 生成完成！', 'green'))
            self.root.after(0, lambda: self._append_output(
                f'\n{"=" * 50}\n✅ 文档已生成：\n   {final_path}\n{"=" * 50}\n'))
            self.root.after(0, lambda: self._set_progress(False))

            # 弹出完成提示
            self.root.after(100, lambda fp=final_path: self._on_complete(fp))

        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            self.root.after(0, lambda: self._set_status(f'异常：{e}', 'red'))
            self.root.after(0, lambda: self._append_output(f'\n❌ 异常：{e}\n{tb}\n'))
            self.root.after(0, lambda: self._set_progress(False))

    def _on_complete(self, filepath):
        """生成完成后弹窗"""
        result = messagebox.askyesno(
            '生成完成！',
            f'文档已保存到：\n{filepath}\n\n是否打开所在文件夹？'
        )
        if result:
            os.startfile(os.path.dirname(filepath))

    def _cancel(self):
        """取消当前生成"""
        self.is_generating = False
        self._set_status('已取消', 'orange')
        self._set_progress(False)

    def _open_output_dir(self):
        os.startfile(OUTPUT_DIR)

    def _about(self):
        messagebox.showinfo(
            '关于',
            '复习文档生成器 v1.0\n\n'
            '填表 → 一键生成带原创配图的 Word 复习文档\n\n'
            '技术栈：Python + tkinter + DeepSeek API\n'
            '         + matplotlib + python-docx\n\n'
            '适用：小学 / 初中 / 高中 / 大学\n'
            '学科：数学 物理 化学 电路 信号与系统 等\n\n'
            '创建日期：2026-06-27\n'
            '已验证：初二物理(21图) / 大一电路基础(22图)'
        )


# ============================================================
# 启动入口
# ============================================================
if __name__ == '__main__':
    root = tk.Tk()
    app = ReviewDocApp(root)

    # 设置窗口图标（如果有的话）
    try:
        root.iconbitmap(default='')
    except:
        pass

    root.mainloop()
