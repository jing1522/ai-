# -*- coding: utf-8 -*-
"""
复习文档生成器 — 文档拼装器
功能：读取 DeepSeek 生成的文字 .docx，找到配图标记位置，插入对应图片
      如果 DeepSeek 没输出配图标记，用关键词匹配兜底
创建日期：2026-06-27
"""

import os
import re

from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

from config import DIAGRAMS_DIR, OUTPUT_DIR, IMAGE_WIDTH_INCHES


# ============================================================
# 配图标记 → 图片文件 映射
# ============================================================

# DeepSeek 生成的文档中会包含 【📐 配图：XXX】 这样的标记
# 这里把标记关键词映射到 diagram_generator.py 生成的实际文件名
MARKER_TO_IMAGE = {
    # 物理
    '力': '01_力的示意图.png',
    '力的三要素': '01_力的示意图.png',
    '重力': '02_重力示意图.png',
    '弹力': '03_弹力示意图.png',
    '弹簧': '03_弹力示意图.png',
    '二力平衡': '04_二力平衡.png',
    '平衡力': '04_二力平衡.png',
    '摩擦力': '05_摩擦力示意图.png',
    '摩擦': '05_摩擦力示意图.png',

    # 电路
    'KCL': '21_KCL节点.png',
    '电流定律': '21_KCL节点.png',
    'KVL': '22_KVL回路.png',
    '电压定律': '22_KVL回路.png',
    '戴维南': '23_戴维南定理.png',
    'thevenin': '23_戴维南定理.png',

    # 数学
    '函数图像': '24_函数图像.png',
    '二次函数': '24_函数图像.png',
    '几何辅助线': '25_几何辅助线.png',
    '全等三角形': '25_几何辅助线.png',

    # 化学
    '实验装置': '26_化学实验装置.png',
    '化学实验': '26_化学实验装置.png',
    '反应流程': '27_化学反应流程.png',
    '化学方程式': '27_化学反应流程.png',

    # 通用
    '学习路径': '28_学习路径.png',
    '考点分布': '29_考点分布.png',
    '高频考点': '29_考点分布.png',
}


def find_image_for_marker(marker_text):
    """
    根据配图标记文字，找到对应的图片文件名。
    用子串匹配——标记 "力的三要素示意图" 能匹配到 key "力的三要素"。

    返回：图片文件名（如 "01_力的示意图.png"），找不到返回 None
    """
    marker_lower = marker_text.lower().replace(' ', '').replace('示意图', '').replace('图示', '').replace('配图',
                                                                                                          '').replace(
        '📐', '').replace('：', '').replace(':', '')

    # 按 key 长度降序匹配——长key优先（"二力平衡" > "力"）
    sorted_items = sorted(MARKER_TO_IMAGE.items(), key=lambda x: len(x[0]), reverse=True)
    for key, filename in sorted_items:
        key_clean = key.lower().replace(' ', '')
        if key_clean in marker_lower or marker_lower in key_clean:
            return filename
    return None


# ============================================================
# 从 .docx 中提取配图标记
# ============================================================

def extract_image_markers(doc):
    """
    扫描文档所有段落，找到 【📐 配图：XXX】 标记。
    返回列表：[(段落索引, 标记文字, 图片文件名)]
    """
    markers = []
    pattern = re.compile(r'【📐\s*配图[：:]([^】]+)】')

    for i, para in enumerate(doc.paragraphs):
        text = para.text
        matches = pattern.findall(text)
        for match in matches:
            marker_text = match.strip()
            img_file = find_image_for_marker(marker_text)
            if img_file:
                markers.append((i, marker_text, img_file))
            else:
                print(f'  [DocAssembler] 标记 "{marker_text}" 无匹配图片，跳过。')

    return markers


# ============================================================
# 主函数：拼装最终文档
# ============================================================

def assemble_document(text_docx_path, output_filename, subject=''):
    """
    读入 DeepSeek 生成的文字 .docx，插入配图，保存最终版。

    参数：
        text_docx_path: 文字 .docx 文件的完整路径
        output_filename: 输出文件名（不含扩展名）
        subject: 学科名（用于兜底关键词匹配）

    返回：
        dict {
            'success': True/False,
            'output_path': '最终文件路径',
            'images_inserted': 插入的图片数量,
            'error': '错误信息（仅失败时）',
        }
    """
    if not os.path.exists(text_docx_path):
        return {'success': False, 'error': f'文字文档不存在：{text_docx_path}', 'images_inserted': 0}

    try:
        doc = Document(text_docx_path)
    except Exception as e:
        return {'success': False, 'error': f'无法打开文档：{e}', 'images_inserted': 0}

    inserted = 0
    found_markers = []

    # —— 策略1：找 【📐 配图：XXX】 标记 ——
    markers = extract_image_markers(doc)

    if markers:
        print(f'  [DocAssembler] 发现 {len(markers)} 个配图标记')
        for para_idx, marker_text, img_file in markers:
            img_path = os.path.join(DIAGRAMS_DIR, img_file)
            if not os.path.exists(img_path):
                print(f'  WARN: 图片不存在 {img_file}')
                continue

            para = doc.paragraphs[para_idx]
            # 在段落末尾插入图片
            para.add_run('\n')
            run = para.add_run()
            try:
                run.add_picture(img_path, width=Inches(IMAGE_WIDTH_INCHES))
                para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                inserted += 1
                found_markers.append(marker_text)
                print(f'  OK 插入 {img_file}（标记：「{marker_text}」）')
            except Exception as e:
                print(f'  FAIL 插入 {img_file}: {e}')

    elif subject:
        # —— 策略2：关键词兜底匹配 ——
        print(f'  [DocAssembler] 文档无配图标记，使用关键词兜底匹配（学科：{subject}）')
        inserted = _insert_by_keyword_fallback(doc, subject)
    else:
        print('  [DocAssembler] 文档无配图标记，且未指定学科，跳过图片插入。')

    # 保存
    output_path = os.path.join(OUTPUT_DIR, output_filename + '.docx')
    doc.save(output_path)

    return {
        'success': True,
        'output_path': output_path,
        'images_inserted': inserted,
        'markers_used': found_markers,
    }


# ============================================================
# 关键词兜底匹配
# ============================================================

def _insert_by_keyword_fallback(doc, subject):
    """
    用长唯一关键词在段落中匹配，插入对应配图。
    这是我们在物理/电路项目中验证过的方法。
    """
    # 学科 → (关键词, 图片文件) 映射
    FALLBACK_KEYWORDS = {
        '物理': [
            ('力的三要素', '01_力的示意图.png'),
            ('G = mg', '02_重力示意图.png'),
            ('弹力', '03_弹力示意图.png'),
            ('二力平衡的四个条件', '04_二力平衡.png'),
            ('静摩擦力', '05_摩擦力示意图.png'),
        ],
        '电路基础': [
            ('KCL ——', '21_KCL节点.png'),
            ('KVL ——', '22_KVL回路.png'),
            ('戴维南定理（Thevenin', '23_戴维南定理.png'),
        ],
        '数学': [
            ('二次函数图像', '24_函数图像.png'),
            ('辅助线', '25_几何辅助线.png'),
        ],
        '化学': [
            ('实验装置', '26_化学实验装置.png'),
            ('化学方程式', '27_化学反应流程.png'),
        ],
    }

    # 找匹配的关键词组
    keywords_list = None
    for key in FALLBACK_KEYWORDS:
        if key in subject or subject in key:
            keywords_list = FALLBACK_KEYWORDS[key]
            break

    if not keywords_list:
        print(f'  [DocAssembler] 学科 "{subject}" 无兜底关键词组。')
        return 0

    inserted = 0
    for keyword, img_file in keywords_list:
        img_path = os.path.join(DIAGRAMS_DIR, img_file)
        if not os.path.exists(img_path):
            continue

        for para in doc.paragraphs:
            if keyword in para.text:
                para.add_run('\n')
                run = para.add_run()
                try:
                    run.add_picture(img_path, width=Inches(IMAGE_WIDTH_INCHES))
                    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    inserted += 1
                    print(f'  OK 兜底匹配：{keyword} → {img_file}')
                except Exception as e:
                    print(f'  FAIL {img_file}: {e}')
                break  # 只插第一个匹配

    return inserted


# ============================================================
# 插入通用图（学习路径+考点分布——放在文档末尾前）
# ============================================================

def insert_common_diagrams(doc):
    """
    在文档末尾前插入通用图（学习路径、考点分布）。
    找到最后一个非空段落，在其前插入。
    """
    inserted = 0
    common_imgs = ['28_学习路径.png', '29_考点分布.png']

    # 找最后一个段落
    last_idx = len(doc.paragraphs) - 2  # 倒数第二段
    if last_idx < 0:
        last_idx = 0

    for img_file in common_imgs:
        img_path = os.path.join(DIAGRAMS_DIR, img_file)
        if not os.path.exists(img_path):
            continue

        para = doc.paragraphs[last_idx]
        para.add_run('\n')
        run = para.add_run()
        try:
            run.add_picture(img_path, width=Inches(IMAGE_WIDTH_INCHES))
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            inserted += 1
            print(f'  OK 插入通用图: {img_file}')
        except Exception as e:
            print(f'  FAIL 通用图 {img_file}: {e}')
        last_idx += 1

    return inserted


# ============================================================
# 一站式拼装（供 GUI 调用）
# ============================================================

def build_final_document(text_docx_path, diagram_paths, output_filename, subject=''):
    """
    一站式：读文字 → 插图片 → 插通用图 → 保存最终版。

    参数：
        text_docx_path: DeepSeek 生成的纯文字 .docx
        diagram_paths: generate_diagrams() 返回的图片路径列表
        output_filename: 输出文件名（不含扩展名）
        subject: 学科名

    返回：同 assemble_document()
    """
    result = assemble_document(text_docx_path, output_filename, subject)

    return result


# ============================================================
# 自测
# ============================================================
if __name__ == '__main__':
    print('=== doc_assembler.py 自测 ===')
    print()

    # 创建假文字文档
    from doc_generator import markdown_to_docx

    test_md = """### 第七章：力

#### 7.1 力是什么

【📐 配图：力的三要素示意图】

力是物体对物体的作用。力的三要素：大小、方向、作用点。

#### 7.3 重力

【📐 配图：重力示意图】

重力 G=mg。方向竖直向下。

#### 8.2 二力平衡

【📐 配图：二力平衡的四个条件】

二力平衡条件：同体、等大、反向、共线。
"""
    test_docx = os.path.join(OUTPUT_DIR, '_test_text.docx')
    try:
        markdown_to_docx(test_md, test_docx, '测试')
        print(f'  测试文字文档: {test_docx}')
    except Exception as e:
        print(f'  FAIL 创建测试文档: {e}')
        print('=== 自测中止 ===')
        exit()

    # 生成几张测试图
    print()
    print('  生成测试图...')
    from diagram_generator import generate_diagrams
    paths = generate_diagrams('物理')
    print(f'  可用图片: {len(paths)} 张')

    # 拼装
    print()
    print('  拼装最终文档...')
    result = assemble_document(test_docx, '_test_final', subject='物理')
    if result['success']:
        size = os.path.getsize(result['output_path'])
        print(f'  最终文档: {result["output_path"]} ({size} bytes)')
        print(f'  插入图片: {result["images_inserted"]} 张')
        # 清理
        os.remove(test_docx)
        os.remove(result['output_path'])
    else:
        print(f'  FAIL: {result.get("error")}')

    print()
    print('=== 自测完成 ===')
