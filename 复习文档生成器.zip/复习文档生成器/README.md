# 复习文档生成器 v1.0

> 填表 → 一键生成带原创配图的 Word 复习文档

## 适用

- **学段：** 小学 / 初中 / 高中 / 大学
- **学科：** 数学 / 物理 / 化学 / 电路基础 / 信号与系统 等
- **难度：** 🟢基础薄弱 / 🟡中等巩固 / 🔴高分冲刺

## 安装

```bash
pip install -r requirements.txt
```

> tkinter 是 Python 自带的，不需要安装。

## 使用

```bash
python main.py
```

1. 填写表单（学段、年级、学期、学科、章节、难度）
2. 输入 DeepSeek API Key（去 platform.deepseek.com/api_keys 免费获取）
3. 勾选「生成配图」
4. 点击 **「▶ 一键生成文档」**
5. 等待 1-3 分钟（取决于文档长度）
6. 弹出完成提示 → 打开 output/ 文件夹获取 .docx

## 文件说明

| 文件 | 作用 |
|------|------|
| `main.py` | GUI 主窗口 |
| `config.py` | 全局配置（路径、API参数、学科选项、配色） |
| `prompt_builder.py` | 提示词组装器（四套学段模板） |
| `doc_generator.py` | DeepSeek API 调用 + Markdown→docx 转换 |
| `diagram_generator.py` | matplotlib 画图引擎（20张图模板） |
| `doc_assembler.py` | 图片插入 Word 拼装器 |
| `requirements.txt` | Python 依赖清单 |
| `settings.json` | API Key 存储（自动生成，不上传） |
| `项目记录.md` | 完整开发记录（供后续维护用） |
| `output/` | 生成的 .docx 输出目录 |
| `diagrams/` | 生成的 .png 图片存放处 |

## 费用

DeepSeek API 调用：生成一份完整复习文档约 **¥0.5-1 元**。

## 已验证项目

- 初二物理下册 —— 21张图，新建模式
- 大一电路基础 —— 22张图，优化模式

## 技术栈

Python + tkinter + DeepSeek API + matplotlib + python-docx
